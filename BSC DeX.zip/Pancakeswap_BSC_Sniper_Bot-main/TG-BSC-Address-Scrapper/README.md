# Trading-Tigers.com Telegram Scrapper

Here you have your much requested Telegram Scrap bot, it filters every message, and looks for valid Web3 addresses and sends them to the Sniper bot.
The Sniper bot should be set correctly to ensure that you do not buy a honeypot.


Don't forget to install the requirements inside Telegram-Scrapper.